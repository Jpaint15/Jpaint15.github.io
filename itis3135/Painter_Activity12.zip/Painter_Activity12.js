$(document).ready(function() {
    $("#slider").bxSlider({
    auto: true,
    randomStart:true,
    slideWidth: 250,
    slideMargin: 10,
    captions:true,
    speed:2000,
    pagerType:'short',
    pagerSelector:'#pager'
});
});